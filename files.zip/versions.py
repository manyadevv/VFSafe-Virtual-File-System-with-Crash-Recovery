"""
versions.py - the Version Store: history of every file + named snapshots.

WHY a separate store?  The journal is emptied by `checkpoint`, so it cannot be
the long-term memory. History therefore lives next to it:

    storage/versions/objects/<sha256>   immutable copy of one file content
                                        (content-addressed: same text = same object)
    storage/versions/history.json       who/what/when: one entry per version,
                                        plus the list of named snapshots

HOW it joins the WAL / recovery system (no change to recovery.py needed)
    * FileManager.apply() calls record_op() / record_snapshot() as part of the
      normal REDO step, so recovery re-runs them exactly like any other change.
    * Both are REPEATABLE: objects are content-addressed, and history.json is
      written once per txid (a txid already present is skipped).
    * history.json and objects are written atomically (tmp file + rename).
    * History is saved BEFORE the data file is touched, so the old content is
      never lost and a crash can't leave a change that has no history entry.

History entry fields: txid, name, op, sha256, size, ts  (+ from / to / source_*)
    op = baseline | create | write | append | restore   -> holds content
         rename (arrives under the new name, holds content)
         rename_out | delete                             -> marker only (sha256 = None)
"""

import json

from errors import StorageError
from storage import bytes_info

CONTENT_OPS = ("create", "write", "append", "restore")


class VersionStore:
    def __init__(self, storage, metadata):
        self.storage = storage
        self.metadata = metadata

    # ------------------------------------------------------------------ disk
    def load_doc(self):
        path = self.storage.history_path
        if not path.exists():
            return {"version": 1, "versions": [], "snapshots": []}
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(doc["versions"], list) or not isinstance(doc["snapshots"], list):
                raise TypeError("wrong layout")
            return doc
        except (ValueError, KeyError, TypeError) as exc:
            raise StorageError("history.json is corrupted (%s)." % exc)

    def _save(self, doc):
        self.storage.write_json_atomic(self.storage.history_path, doc)

    # ------------------------------------------------------ recording (REDO-safe)
    def record_op(self, record):
        """Remember the version created by a BEGIN record. Repeatable per txid."""
        doc = self.load_doc()
        txid, op, name, ts = record["txid"], record["op"], record["name"], record.get("ts", "")
        if any(v["txid"] == txid for v in doc["versions"]):
            return                                           # already recorded: redo is a no-op
        new = []

        # Files that existed before history was switched on: keep their current content.
        if op != "create" and not any(v["name"] == name for v in doc["versions"]):
            self._seed_baseline(name, new)

        if op in CONTENT_OPS:
            data = record["content"].encode("utf-8")
            sha = self.storage.write_object(data)
            entry = {"txid": txid, "name": name, "op": op, "sha256": sha,
                     "size": len(data), "ts": ts}
            for key in ("source_txid", "source_snapshot"):
                if record.get(key) is not None:
                    entry[key] = record[key]
            new.append(entry)
        elif op == "delete":
            new.append({"txid": txid, "name": name, "op": "delete", "sha256": None, "ts": ts})
        elif op == "rename":
            meta = self.metadata.get(name) or {}
            sha, size = meta.get("sha256"), meta.get("size")
            if sha is not None and not self._ensure_object(sha, name):
                sha = None                                   # content unavailable: marker only
            new.append({"txid": txid, "name": name, "op": "rename_out",
                        "to": record["new_name"], "sha256": None, "ts": ts})
            new.append({"txid": txid, "name": record["new_name"], "op": "rename",
                        "from": name, "sha256": sha, "size": size, "ts": ts})
        doc["versions"].extend(new)
        self._save(doc)

    def record_snapshot(self, record):
        """Remember a named snapshot (a name -> sha256 manifest). Repeatable per txid."""
        doc = self.load_doc()
        if any(s["txid"] == record["txid"] for s in doc["snapshots"]):
            return
        doc["snapshots"].append({"name": record["name"], "txid": record["txid"],
                                 "ts": record.get("ts", ""), "files": record["files"]})
        self._save(doc)

    def ensure_objects(self, files):
        """Make sure every manifest entry has a stored object. Returns names that could not."""
        return [n for n, info in sorted(files.items()) if not self._ensure_object(info["sha256"], n)]

    def _ensure_object(self, sha, name):
        if self.storage.has_valid_object(sha):
            return True
        try:                                                 # fall back to the live data file
            data = self.storage.file_path(name).read_bytes()
        except OSError:
            return False
        if bytes_info(data)[1] != sha:
            return False
        self.storage.write_object(data)
        return True

    def _seed_baseline(self, name, out):
        meta = self.metadata.get(name)
        if not meta or not self._ensure_object(meta["sha256"], name):
            return
        out.append({"txid": meta["last_txid"], "name": name, "op": "baseline",
                    "sha256": meta["sha256"], "size": meta["size"], "ts": meta["modified"]})

    # --------------------------------------------------------------- queries
    def history(self, name):
        """All entries in the life of `name` (case-insensitive), following renames backwards."""
        doc = self.load_doc()
        found, seen = {}, set()

        def walk(wanted, bound):
            if (wanted.lower(), bound) in seen:
                return
            seen.add((wanted.lower(), bound))
            for v in doc["versions"]:
                if v["name"].lower() == wanted.lower() and (bound is None or v["txid"] < bound):
                    found[(v["txid"], v["name"])] = v
                    if v["op"] == "rename":
                        walk(v["from"], v["txid"])

        walk(name, None)
        return sorted(found.values(), key=lambda v: (v["txid"], v["op"] == "rename"))

    def snapshots(self):
        return sorted(self.load_doc()["snapshots"], key=lambda s: s["txid"])

    def get_snapshot(self, name):
        for snap in self.load_doc()["snapshots"]:
            if snap["name"].lower() == name.lower():
                return snap
        return None
