"""Runs a small, fixed-seed batch of the crash fuzzer so `python -m unittest` covers it too."""

import unittest

from tests.run_crash_fuzz import run_fuzz


class FuzzSmokeTest(unittest.TestCase):
    def test_fixed_seed_batch_passes(self):
        lines = []
        ok = run_fuzz(seed=2026, scenarios=25, out=lines.append)
        self.assertTrue(ok, "\n".join(lines))

    def test_same_seed_gives_same_operations(self):
        a, b = [], []
        run_fuzz(seed=5, scenarios=1, only=0, verbose=True, out=a.append)
        run_fuzz(seed=5, scenarios=1, only=0, verbose=True, out=b.append)
        self.assertEqual([x for x in a if "passed=" not in x], [x for x in b if "passed=" not in x])


if __name__ == "__main__":
    unittest.main()
