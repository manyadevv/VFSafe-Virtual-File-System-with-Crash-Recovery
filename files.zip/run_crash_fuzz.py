"""
run_crash_fuzz.py - randomized crash testing for VFSafe.

Each SCENARIO uses its own temporary storage and its own random stream derived
from (--seed, scenario number), so any failure can be replayed exactly:

    python tests/run_crash_fuzz.py --seed 42 --scenarios 200
    python tests/run_crash_fuzz.py --seed 42 --only 17 --verbose     # replay scenario 17

A scenario is a random list of operations (create / write / append / rename /
delete / snapshot create / restore by txid / restore from snapshot / checkpoint).
About 40% of them are run with a crash armed at one of the existing crash points;
sometimes recovery itself is crashed too. After every crash the "program" is
restarted (a new FileManager = automatic recovery) and we verify:

  * recovery left no pending journal records and a second restart does nothing
  * fsck is completely clean (no errors, no warnings)
  * the files and their contents equal an independent in-memory model
    (operation either fully happened or never happened, per the recovery policy)
  * every file's stored SHA-256 equals the SHA-256 of the expected content
  * every snapshot holds exactly the expected files and contents
  * every recorded historical version still reads back with the expected content
"""

import argparse
import hashlib
import os
import random
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from consistency import ConsistencyChecker          # noqa: E402
from crash import OPERATION_CRASH_POINTS, CrashSimulator  # noqa: E402
from errors import SimulatedCrash, VFSafeError       # noqa: E402
from file_manager import FileManager                 # noqa: E402
from journal import Journal                          # noqa: E402

NAMES = ["a.txt", "b.txt", "c.log", "d.md"]
WORDS = ["alpha", "beta", "gamma", "delta", "line\nbreak", "caf\u00e9", "x" * 40]
# Per the documented recovery policy: did the operation take effect after a crash?
HAPPENED = {"before_journal": False, "during_journal": False, "after_journal": True,
            "during_apply": True, "after_apply": True, "after_commit": True}


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class Failure(Exception):
    pass


class Model:
    """What the file system SHOULD contain, computed independently of VFSafe."""

    def __init__(self):
        self.files = {}      # name -> content
        self.hist = {}       # name -> {txid: content}  (lineage follows renames)
        self.snaps = {}      # snapshot name -> {file: content}

    def add_version(self, name, txid, content):
        self.hist.setdefault(name, {})[txid] = content

    def rename(self, old, new, txid):
        merged = dict(self.hist.get(new, {}))
        merged.update(self.hist.get(old, {}))
        self.hist[new] = merged
        self.files[new] = self.files.pop(old)
        self.add_version(new, txid, self.files[new])


class Scenario:
    def __init__(self, seed, index, verbose=False, keep=False):
        self.seed, self.index, self.verbose, self.keep = seed, index, verbose, keep
        self.rng = random.Random("%s:%s" % (seed, index))
        self.log = []
        self.model = Model()
        self.snap_counter = 0
        self.dir = Path(tempfile.mkdtemp(prefix="vfsafe_fuzz_"))
        self.root = self.dir / "storage"
        self.fm = FileManager(self.root)

    def note(self, text):
        self.log.append(text)
        if self.verbose:
            print("    " + text)

    # ------------------------------------------------------------ operation choice
    def choose_op(self):
        m, rng = self.model, self.rng
        names, free = sorted(m.files), [n for n in NAMES if n not in m.files]
        choices = []
        if free:
            choices += ["create"] * 3
        if names:
            choices += ["write", "append", "delete"] * 2 + ["snapshot"] * 2
        if free and names:
            choices += ["rename"] * 3
        restorable = [n for n in NAMES if m.hist.get(n)]
        if restorable:
            choices += ["restore_tx"] * 3
        if any(m.snaps.values()):
            choices += ["restore_snap"] * 2
        choices += ["snapshot", "checkpoint"] if not names else ["checkpoint"]
        kind = rng.choice(choices)
        text = rng.choice(WORDS) + str(rng.randint(0, 99))
        if kind == "create":
            return ("create", rng.choice(free), text)
        if kind == "write":
            return ("write", rng.choice(names), text)
        if kind == "append":
            return ("append", rng.choice(names), text)
        if kind == "delete":
            return ("delete", rng.choice(names))
        if kind == "rename":
            return ("rename", rng.choice(names), rng.choice(free))
        if kind == "snapshot":
            self.snap_counter += 1
            return ("snapshot", "snap%d" % self.snap_counter)
        if kind == "restore_tx":
            name = rng.choice(restorable)
            return ("restore_tx", name, rng.choice(sorted(m.hist[name])))
        if kind == "restore_snap":
            options = [(s, f) for s, files in sorted(m.snaps.items()) for f in sorted(files)]
            snap, name = rng.choice(options)
            return ("restore_snap", name, snap)
        return ("checkpoint",)

    # ---------------------------------------------------- run op / expected result
    def perform(self, fm, op):
        kind = op[0]
        if kind == "create":
            fm.create(op[1], op[2])
        elif kind == "write":
            fm.write(op[1], op[2])
        elif kind == "append":
            fm.append(op[1], op[2])
        elif kind == "delete":
            fm.delete(op[1])
        elif kind == "rename":
            fm.rename(op[1], op[2])
        elif kind == "snapshot":
            fm.snapshot_create(op[1])
        elif kind == "restore_tx":
            fm.restore(op[1], txid=op[2])
        elif kind == "restore_snap":
            fm.restore(op[1], snapshot=op[2])
        elif kind == "checkpoint":
            fm.journal.checkpoint()

    def expect(self, op, txid):
        """Update the model as if `op` took effect (with transaction id `txid`)."""
        m, kind = self.model, op[0]
        if kind in ("create", "write"):
            m.files[op[1]] = op[2]
        elif kind == "append":
            m.files[op[1]] += op[2]
        elif kind == "delete":
            del m.files[op[1]]
            return
        elif kind == "rename":
            m.rename(op[1], op[2], txid)
            return
        elif kind == "snapshot":
            m.snaps[op[1]] = dict(m.files)
            return
        elif kind == "restore_tx":
            m.files[op[1]] = m.hist[op[1]][op[2]]
        elif kind == "restore_snap":
            m.files[op[1]] = m.snaps[op[2]][op[1]]
        else:
            return
        m.add_version(op[1], txid, m.files[op[1]])

    @staticmethod
    def last_txid(fm):
        return max([r["txid"] for r in fm.journal.read_all().records], default=0)

    # ------------------------------------------------------------------ verification
    def verify(self, fm, where):
        problems = []
        m = self.model
        scan = fm.journal.read_all()
        if Journal.pending_from(scan.records) or scan.torn_tail:
            problems.append("journal still has pending/torn records")
        report = ConsistencyChecker(fm).check()
        if not report.is_clean:
            problems += ["fsck: " + line.strip() for line in report.summary_lines()]
        actual = {f["name"]: f for f in fm.list_files()}
        if sorted(actual) != sorted(m.files):
            problems.append("file list is %s, expected %s" % (sorted(actual), sorted(m.files)))
        for name, content in sorted(m.files.items()):
            if name not in actual:
                continue
            got = fm.read(name)
            if got != content:
                problems.append("content of %s is %r, expected %r" % (name, got, content))
            if actual[name]["sha256"] != sha(content):
                problems.append("stored SHA-256 of %s differs from expected content" % name)
            disk = hashlib.sha256(fm.storage.file_path(name).read_bytes()).hexdigest()
            if disk != sha(content):
                problems.append("SHA-256 of data file %s differs from expected content" % name)
        have = {s["name"]: s for s in fm.snapshot_list()}
        if sorted(have) != sorted(m.snaps):
            problems.append("snapshots are %s, expected %s" % (sorted(have), sorted(m.snaps)))
        for sname, files in sorted(m.snaps.items()):
            if sname not in have:
                continue
            got = {n: i["sha256"] for n, i in have[sname]["files"].items()}
            want = {n: sha(c) for n, c in files.items()}
            if got != want:
                problems.append("snapshot %s manifest differs from expected" % sname)
        for name, versions in sorted(m.hist.items()):
            try:
                have_tx = {e["txid"] for e in fm.history(name) if e["sha256"]}
            except VFSafeError as exc:
                problems.append("history(%s) failed: %s" % (name, exc))
                continue
            if have_tx != set(versions):
                problems.append("history of %s has txids %s, expected %s"
                                % (name, sorted(have_tx), sorted(versions)))
            for txid, content in sorted(versions.items()):
                try:
                    if fm.read_version(name, txid)[1] != content:
                        problems.append("version tx %d of %s has wrong content" % (txid, name))
                except VFSafeError as exc:
                    problems.append("version tx %d of %s unreadable: %s" % (txid, name, exc))
        if problems:
            raise Failure("%s:\n      - %s" % (where, "\n      - ".join(problems)))

    # ------------------------------------------------------------------------- main
    def run(self, max_ops):
        rng = self.rng
        fm = self.fm
        for step in range(rng.randint(4, max_ops)):
            op = self.choose_op()
            point = rng.choice(OPERATION_CRASH_POINTS) if (
                op[0] != "checkpoint" and rng.random() < 0.4) else None
            label = "step %d: %s%s" % (step + 1, " ".join(map(str, op)),
                                       "   [crash at %s]" % point if point else "")
            self.note(label)
            if point:
                fm.crash.arm(point)
            try:
                self.perform(fm, op)
                crashed = False
            except SimulatedCrash as crash:
                crashed = True
                if crash.point != point:
                    raise Failure("%s: crashed at unexpected point %s" % (label, crash.point))
            except VFSafeError as exc:
                raise Failure("%s: unexpected error: %s" % (label, exc))
            if point and not crashed:
                fm.crash.disarm()
                raise Failure("%s: armed crash point never fired" % label)

            if crashed:
                if rng.random() < 0.25:               # crash INSIDE recovery as well
                    sim = CrashSimulator()
                    sim.arm("during_recovery")
                    try:
                        FileManager(self.root, crash=sim)
                    except SimulatedCrash:
                        self.note("  recovery itself crashed, restarting again")
                fm = self.fm = FileManager(self.root)           # restart = recovery
                if HAPPENED[point]:
                    self.expect(op, self.last_txid(fm))
                self.verify(fm, "%s -> after crash and recovery" % label)
            else:
                self.expect(op, self.last_txid(fm))
                if rng.random() < 0.3:                   # clean restart now and then
                    fm = self.fm = FileManager(self.root)
                self.verify(fm, "%s -> after normal run" % label)

        fm = self.fm = FileManager(self.root)
        if not fm.recovery_report.nothing_to_do:
            raise Failure("final restart still had work to recover: %s"
                          % fm.recovery_report.summary_lines())
        self.verify(fm, "final restart")

    def cleanup(self, failed):
        if failed and self.keep:
            return str(self.dir)
        shutil.rmtree(self.dir, ignore_errors=True)
        return None


def run_fuzz(seed, scenarios, max_ops=14, only=None, verbose=False, keep=False, out=print):
    indexes = [only] if only is not None else range(scenarios)
    passed, failures = 0, []
    started = time.time()
    for i in indexes:
        sc = Scenario(seed, i, verbose=verbose, keep=keep)
        if verbose:
            out("scenario %d (seed %s)" % (i, seed))
        error, trace = None, None
        try:
            sc.run(max_ops)
        except Failure as exc:
            error = str(exc)
        except Exception as exc:                          # a bug in VFSafe or in the fuzzer
            import traceback
            error, trace = "%s: %s" % (type(exc).__name__, exc), traceback.format_exc()
        kept = sc.cleanup(error is not None)
        if error is None:
            passed += 1
        else:
            failures.append((i, error, sc.log, kept, trace))
    out("")
    for i, error, log, kept, trace in failures:
        out("FAILED scenario %d" % i)
        out("  reason: " + error)
        out("  operations so far:")
        for line in log:
            out("    " + line)
        if trace:
            out(trace)
        if kept:
            out("  storage kept at: " + kept)
        out("  reproduce: python tests/run_crash_fuzz.py --seed %s --only %d --verbose" % (seed, i))
        out("")
    out("Crash fuzz: seed=%s  scenarios=%d  passed=%d  failed=%d  (%.1fs)"
        % (seed, len(list(indexes)), passed, len(failures), time.time() - started))
    return not failures


def main(argv=None):
    parser = argparse.ArgumentParser(description="Randomized crash testing for VFSafe.")
    parser.add_argument("--seed", type=int, default=None, help="random seed (default: random, printed)")
    parser.add_argument("--scenarios", type=int, default=100, help="number of scenarios (default 100)")
    parser.add_argument("--max-ops", type=int, default=14, help="max operations per scenario")
    parser.add_argument("--only", type=int, help="run just this scenario number (to replay a failure)")
    parser.add_argument("--verbose", action="store_true", help="print every step")
    parser.add_argument("--keep-failed", action="store_true", help="keep storage of failed scenarios")
    args = parser.parse_args(argv)
    seed = args.seed if args.seed is not None else random.SystemRandom().randint(0, 10**6)
    ok = run_fuzz(seed, args.scenarios, args.max_ops, args.only, args.verbose, args.keep_failed)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
