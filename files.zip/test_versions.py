"""Tests for snapshots, history and restore (including crashes and damaged history)."""

import subprocess
import sys
from pathlib import Path

from consistency import ConsistencyChecker
from crash import OPERATION_CRASH_POINTS, CrashSimulator
from errors import (FileAlreadyExistsError, FileMissingError, SimulatedCrash,
                    StorageError, VFSafeError)
from file_manager import FileManager
from storage import content_info
from tests.helpers import VFSTestCase

MAIN = str(Path(__file__).resolve().parent.parent / "main.py")
ROLL_FORWARD = ["after_journal", "during_apply", "after_apply", "after_commit"]
NEVER = ["before_journal", "during_journal"]


def txids(fm, name):
    return [e["txid"] for e in fm.history(name) if e["sha256"]]


class HistoryTest(VFSTestCase):
    def test_overwrite_and_append_keep_old_versions(self):
        t1 = self.fm.create("a.txt", "one")
        t2 = self.fm.write("a.txt", "two")
        t3 = self.fm.append("a.txt", "+3")
        self.assertEqual(txids(self.fm, "a.txt"), [t1, t2, t3])
        self.assertEqual(self.fm.read_version("a.txt", t1)[1], "one")
        self.assertEqual(self.fm.read_version("a.txt", t2)[1], "two")
        self.assertEqual(self.fm.read_version("a.txt", t3)[1], "two+3")
        self.assertTrue(self.fm.history("a.txt")[-1]["current"])

    def test_history_survives_checkpoint_and_restart(self):
        t1 = self.fm.create("a.txt", "one")
        self.fm.write("a.txt", "two")
        self.fm.journal.checkpoint()
        fm = self.restart()
        self.assertEqual(fm.read_version("a.txt", t1)[1], "one")

    def test_rename_keeps_history_under_both_names(self):
        t1 = self.fm.create("a.txt", "one")
        t2 = self.fm.rename("a.txt", "b.txt")
        t3 = self.fm.write("b.txt", "two")
        self.assertEqual(txids(self.fm, "b.txt"), [t1, t2, t3])
        self.assertEqual(self.fm.read_version("b.txt", t1)[1], "one")
        self.assertEqual(txids(self.fm, "a.txt"), [t1])      # old name: life before the rename

    def test_delete_keeps_history_and_restore_recreates_file(self):
        t1 = self.fm.create("a.txt", "precious")
        self.fm.delete("a.txt")
        self.assertEqual(self.fm.history("a.txt")[-1]["op"], "delete")
        self.fm.restore("a.txt", txid=t1)
        self.assertEqual(self.fm.read("a.txt"), "precious")

    def test_history_of_unknown_file(self):
        with self.assertRaises(FileMissingError):
            self.fm.history("nothing.txt")

    def test_legacy_file_gets_a_baseline(self):
        """A file made before history existed is preserved on its first change."""
        self.fm.create("a.txt", "old")
        self.fm.storage.history_path.unlink()
        self.fm.write("a.txt", "new")
        ops = [e["op"] for e in self.fm.history("a.txt")]
        self.assertEqual(ops, ["baseline", "write"])
        self.assertEqual(self.fm.read_version("a.txt", self.fm.history("a.txt")[0]["txid"])[1], "old")


class RestoreTest(VFSTestCase):
    def test_restore_by_txid_adds_new_version_and_verifies(self):
        t1 = self.fm.create("a.txt", "one")
        self.fm.write("a.txt", "two")
        res = self.fm.restore("a.txt", txid=t1)
        self.assertEqual(self.fm.read("a.txt"), "one")
        self.assertTrue(res["verified"])
        self.assertEqual(res["sha256"], content_info("one")[1])
        self.assertEqual(self.fm.stat("a.txt")["sha256"], content_info("one")[1])
        self.assertEqual(self.fm.history("a.txt")[-1]["op"], "restore")
        self.assertEqual(len(txids(self.fm, "a.txt")), 3)     # history was not rewritten
        self.assertTrue(ConsistencyChecker(self.fm).check().is_clean)

    def test_restore_unknown_txid_and_marker_txid(self):
        self.fm.create("a.txt", "one")
        tdel = self.fm.delete("a.txt")
        with self.assertRaises(VFSafeError):
            self.fm.restore("a.txt", txid=999)
        with self.assertRaises(VFSafeError) as ctx:
            self.fm.restore("a.txt", txid=tdel)
        self.assertIn("no content", str(ctx.exception))

    def test_restore_needs_exactly_one_source(self):
        self.fm.create("a.txt", "one")
        with self.assertRaises(VFSafeError):
            self.fm.restore("a.txt")

    def test_damaged_history_object_is_detected_not_restored(self):
        t1 = self.fm.create("a.txt", "one")
        self.fm.write("a.txt", "two")
        sha = content_info("one")[1]
        self.fm.storage.object_path(sha).write_bytes(b"tampered")
        with self.assertRaises(StorageError) as ctx:
            self.fm.restore("a.txt", txid=t1)
        self.assertIn("corrupted", str(ctx.exception))
        self.assertEqual(self.fm.read("a.txt"), "two")             # nothing was changed
        self.assertEqual(self.fm.journal.pending_from(self.fm.journal.read_all().records), [])
        codes = [i.code for i in ConsistencyChecker(self.fm).check().errors]
        self.assertIn("OBJECT_CORRUPT", codes)

    def test_fsck_reports_missing_history_object(self):
        self.fm.create("a.txt", "one")
        self.fm.storage.object_path(content_info("one")[1]).unlink()
        self.assertIn("OBJECT_MISSING", [i.code for i in ConsistencyChecker(self.fm).check().errors])


class SnapshotTest(VFSTestCase):
    def test_create_list_and_duplicate(self):
        self.fm.create("a.txt", "A")
        self.fm.create("b.txt", "B")
        txid = self.fm.snapshot_create("s1")
        snaps = self.fm.snapshot_list()
        self.assertEqual([(s["name"], s["txid"], sorted(s["files"])) for s in snaps],
                         [("s1", txid, ["a.txt", "b.txt"])])
        with self.assertRaises(FileAlreadyExistsError):
            self.fm.snapshot_create("S1")
        self.assertTrue(ConsistencyChecker(self.fm).check().is_clean)

    def test_restore_from_snapshot_after_change_and_delete(self):
        self.fm.create("a.txt", "A1")
        self.fm.snapshot_create("s1")
        self.fm.write("a.txt", "A2")
        self.fm.delete("a.txt")
        res = self.fm.restore("a.txt", snapshot="s1")
        self.assertEqual(self.fm.read("a.txt"), "A1")
        self.assertEqual(res["source_snapshot"], "s1")

    def test_restore_from_snapshot_errors(self):
        self.fm.create("a.txt", "A")
        self.fm.snapshot_create("s1")
        self.fm.create("b.txt", "B")
        with self.assertRaises(FileMissingError):
            self.fm.restore("a.txt", snapshot="nope")
        with self.assertRaises(FileMissingError):
            self.fm.restore("b.txt", snapshot="s1")

    def test_snapshot_survives_checkpoint_restart(self):
        self.fm.create("a.txt", "A")
        self.fm.snapshot_create("s1")
        self.fm.journal.checkpoint()
        self.fm.write("a.txt", "A2")
        fm = self.restart()
        fm.restore("a.txt", snapshot="s1")
        self.assertEqual(fm.read("a.txt"), "A")


class VersionCrashTest(VFSTestCase):
    """Every crash point x (snapshot, restore): recovery gives all-or-nothing, fsck clean."""

    def prepare(self):
        self.fm.create("a.txt", "AAA")
        self.t_old = self.fm.write("a.txt", "BBB")
        self.fm.create("b.txt", "bbb")

    def run_crash(self, point, action):
        fm = self.restart()
        self.crash(fm, point, action, fm)
        fm2 = self.restart()
        report = fm2.recovery_report
        self.assertTrue(report.consistency.is_clean, report.consistency.summary_lines())
        self.assertTrue(ConsistencyChecker(fm2).check().is_clean)
        self.assertEqual(self.restart().recovery_report.redone, [])    # recovery is repeatable
        return fm2

    def test_snapshot_create_crash_matrix(self):
        for point in OPERATION_CRASH_POINTS:
            with self.subTest(point=point):
                self.reset_storage(); self.prepare()
                fm = self.run_crash(point, lambda f: f.snapshot_create("s1"))
                if point in ROLL_FORWARD:
                    snap = fm.versions.get_snapshot("s1")
                    self.assertEqual(sorted(snap["files"]), ["a.txt", "b.txt"])
                    fm.write("a.txt", "CHANGED")
                    fm.restore("a.txt", snapshot="s1")
                    self.assertEqual(fm.read("a.txt"), "BBB")
                else:
                    self.assertEqual(fm.snapshot_list(), [])
                    fm.snapshot_create("s1")                          # can simply be redone

    def test_restore_crash_matrix(self):
        sha_old = content_info("AAA")[1]
        for point in OPERATION_CRASH_POINTS:
            with self.subTest(point=point):
                self.reset_storage(); self.prepare()
                t1 = self.fm.history("a.txt")[0]["txid"]
                fm = self.run_crash(point, lambda f: f.restore("a.txt", txid=t1))
                expect = "AAA" if point in ROLL_FORWARD else "BBB"
                self.assertEqual(fm.read("a.txt"), expect)
                self.assertEqual(fm.stat("a.txt")["sha256"], content_info(expect)[1])
                self.assertEqual(fm.read_version("a.txt", t1)[1], "AAA")   # history intact

    def test_crash_in_recovery_of_restore(self):
        self.prepare()
        t1 = self.fm.history("a.txt")[0]["txid"]
        fm = self.restart()
        self.crash(fm, "during_apply", lambda: fm.restore("a.txt", txid=t1))
        sim = CrashSimulator(); sim.arm("during_recovery")
        with self.assertRaises(SimulatedCrash):
            FileManager(self.root, crash=sim)
        fm3 = self.restart()
        self.assertEqual(fm3.read("a.txt"), "AAA")
        self.assertTrue(ConsistencyChecker(fm3).check().is_clean)


class VersionCliTest(VFSTestCase):
    def cli(self, *args):
        r = subprocess.run([sys.executable, MAIN, "--storage", str(self.root)] + list(args),
                           capture_output=True, text=True, timeout=60)
        return r.returncode, r.stdout + r.stderr

    def test_full_cli_flow(self):
        self.cli("create", "a.txt", "v1"); self.cli("write", "a.txt", "v2")
        self.assertEqual(self.cli("snapshot", "create", "s1")[0], 0)
        self.cli("write", "a.txt", "v3")
        code, out = self.cli("snapshot", "list")
        self.assertIn("s1", out)
        code, out = self.cli("history", "a.txt")
        self.assertIn("<- CURRENT", out)
        code, out = self.cli("restore", "a.txt", "--txid", "1")
        self.assertEqual(code, 0)
        self.assertIn("SHA-256 verified", out)
        self.assertIn("v1", self.cli("read", "a.txt")[1])
        self.assertEqual(self.cli("restore", "a.txt", "--snapshot", "s1")[0], 0)
        self.assertIn("v2", self.cli("read", "a.txt")[1])

    def test_cli_errors_are_friendly(self):
        self.cli("create", "a.txt", "v1")
        code, out = self.cli("restore", "a.txt", "--txid", "77")
        self.assertEqual(code, 1); self.assertNotIn("Traceback", out)
        self.assertEqual(self.cli("restore", "a.txt")[0], 2)         # argparse: source required

    def test_crash_during_restore_via_cli_then_recovery(self):
        self.cli("create", "a.txt", "old"); self.cli("write", "a.txt", "new")
        code, out = self.cli("restore", "a.txt", "--txid", "1", "--crash-at", "during_apply")
        self.assertEqual(code, 99)
        self.assertIn("PENDING", self.cli("--no-recover", "journal")[1])
        code, out = self.cli("read", "a.txt")
        self.assertIn("REDONE", out); self.assertIn("old", out)
        self.assertIn("OK", self.cli("fsck")[1])
