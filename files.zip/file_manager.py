"""
file_manager.py - the File Operation Manager (the heart of VFSafe).

Every changing operation (create / write / append / rename / delete) follows
the SAME 5 steps:

    1. validate the input                    (bad input never touches the journal)
    2. write BEGIN to the journal  (+fsync)  <- "write-ahead": note first ...
    3. apply the change to data + metadata   <- ... then do the work
    4. write COMMIT to the journal (+fsync)  <- "it is done"
    5. report success to the user            (only after COMMIT)

Between the steps there are crash checkpoints (see crash.py). If the program
dies at any of them, recovery.py repairs the state at the next start-up.
"""

import time

from crash import CrashSimulator
from errors import (
    FileAlreadyExistsError,
    FileMissingError,
    SimulatedCrash,
    StorageError,
    VFSafeError,
)
from journal import Journal
from metadata import MetadataManager
from recovery import RecoveryManager
from versions import CONTENT_OPS, VersionStore
from storage import Storage, bytes_info
from validation import validate_content, validate_name


def now_string():
    return time.strftime("%Y-%m-%d %H:%M:%S")


class FileManager:
    def __init__(self, storage_root, auto_recover=True, crash=None):
        """
        storage_root : folder that holds the whole virtual file system
        auto_recover : run crash recovery right now (this is what "restart" does)
        crash        : optional CrashSimulator (a new one is created if omitted)
        """
        self.storage = Storage(storage_root)
        self.storage.initialize()
        self.crash = crash if crash is not None else CrashSimulator()
        self.metadata = MetadataManager(self.storage)
        self.versions = VersionStore(self.storage, self.metadata)
        self.journal = Journal(self.storage.journal_path, crash=self.crash)
        self.recovery_report = None
        self._blocked_reason = None

        if auto_recover:
            self.recovery_report = self.recover()
        else:
            scan = self.journal.read_all()
            if scan.torn_tail or Journal.pending_from(scan.records):
                self._blocked_reason = (
                    "The journal contains unfinished work. Run recovery before new operations."
                )

    # =========================================================== public: recovery
    def recover(self):
        """Run crash recovery now. Safe to call as often as you like."""
        try:
            report = RecoveryManager(self).recover()
        except SimulatedCrash:
            self._blocked_reason = "This FileManager 'crashed'. Create a new one to restart."
            raise
        self._blocked_reason = None
        return report

    # ========================================================= public: operations
    def create(self, name, content=""):
        self._check_not_blocked()
        name = validate_name(name)
        content = validate_content(content)
        if self.metadata.find_ci(name) is not None:
            raise FileAlreadyExistsError("File '%s' already exists." % name)
        return self._run("create", name=name, content=content)

    def write(self, name, content):
        self._check_not_blocked()
        actual = self._resolve(name)
        content = validate_content(content)
        return self._run("write", name=actual, content=content)

    def append(self, name, text):
        self._check_not_blocked()
        actual = self._resolve(name)
        new_content = validate_content(self.storage.read_file(actual) + validate_content(text))
        # The journal stores the FINAL content, so redoing it twice is harmless.
        return self._run("append", name=actual, content=new_content)

    def rename(self, old_name, new_name):
        self._check_not_blocked()
        old_actual = self._resolve(old_name)
        new_name = validate_name(new_name)
        if old_actual.lower() == new_name.lower():
            raise VFSafeError("The new name is the same as the old name.")
        if self.metadata.find_ci(new_name) is not None:
            raise FileAlreadyExistsError("Cannot rename: '%s' already exists." % new_name)
        return self._run("rename", name=old_actual, new_name=new_name)

    def delete(self, name):
        self._check_not_blocked()
        actual = self._resolve(name)
        return self._run("delete", name=actual)

    # ============================================ public: snapshots, history, restore
    def snapshot_create(self, snap_name):
        """Freeze the current content of every file under a name. Journaled like any change."""
        self._check_not_blocked()
        snap_name = validate_name(snap_name)
        if self.versions.get_snapshot(snap_name) is not None:
            raise FileAlreadyExistsError("Snapshot '%s' already exists." % snap_name)
        files = {n: {"sha256": e["sha256"], "size": e["size"]}
                 for n, e in self.metadata.files.items()}
        # Everything that can fail is checked BEFORE the journal is written, so a
        # logged snapshot can always be completed by recovery.
        for n, info in files.items():
            if not self.versions._ensure_object(info["sha256"], n):
                raise StorageError("Cannot snapshot: the data of '%s' is damaged. Run 'fsck'." % n)
        return self._run("snapshot", name=snap_name, files=files)

    def snapshot_list(self):
        return self.versions.snapshots()

    def history(self, name):
        """Versions of a file (works for deleted files too). Marks the current one."""
        name = validate_name(name)
        actual = self.metadata.find_ci(name) or name
        entries = self.versions.history(actual)
        if not entries:
            raise FileMissingError("No history for '%s'." % name)
        current = self.metadata.get(actual)
        result = []
        for e in entries:
            e = dict(e)
            e["current"] = bool(current and e["name"] == actual
                                and e["txid"] == current["last_txid"] and e["sha256"])
            result.append(e)
        return result

    def read_version(self, name, txid):
        """(entry, text) of the version created by transaction `txid`, SHA-256 verified."""
        entries = self.history(name)
        same = [e for e in entries if e["txid"] == txid]
        if not same:
            raise VFSafeError("'%s' has no version with txid %s (see: history %s)." % (name, txid, name))
        holders = [e for e in same if e["sha256"]]
        if not holders:
            raise VFSafeError("Transaction %s was a '%s' of '%s' and holds no content to restore."
                              % (txid, same[0]["op"], name))
        entry = holders[0]
        return entry, self._decode(self.storage.read_object(entry["sha256"]), name)

    def restore(self, name, txid=None, snapshot=None):
        """
        Bring a file back to an earlier version (by txid, or from a snapshot).
        The restore is a normal journaled operation, so history is never rewritten:
        it simply adds a NEW version whose content equals the old one.
        """
        self._check_not_blocked()
        if (txid is None) == (snapshot is None):
            raise VFSafeError("Give exactly one of: a txid or a snapshot name.")
        name = validate_name(name)
        actual = self.metadata.find_ci(name) or name
        if txid is not None:
            entry, content = self.read_version(actual, txid)       # verifies SHA-256
            sha, source = entry["sha256"], {"source_txid": txid}
        else:
            snap = self.versions.get_snapshot(validate_name(snapshot))
            if snap is None:
                raise FileMissingError("Snapshot '%s' does not exist." % snapshot)
            info = next((i for n, i in snap["files"].items() if n.lower() == actual.lower()), None)
            if info is None:
                raise FileMissingError("'%s' was not in snapshot '%s'." % (name, snap["name"]))
            sha = info["sha256"]
            content = self._decode(self.storage.read_object(sha), actual)  # verifies SHA-256
            source = {"source_txid": snap["txid"], "source_snapshot": snap["name"]}
        content = validate_content(content)
        new_txid = self._run("restore", name=actual, content=content, sha256=sha, **source)
        # Post-check: what is now on disk must hash to the version we asked for.
        disk_sha = bytes_info(self.storage.file_path(actual).read_bytes())[1]
        if disk_sha != sha or self.metadata.get(actual)["sha256"] != sha:
            raise StorageError("Restore verification FAILED for '%s'. Run 'fsck'." % actual)
        return {"txid": new_txid, "name": actual, "sha256": sha, "verified": True, **source}

    # ============================================================ public: queries
    def read(self, name):
        return self.storage.read_file(self._resolve(name))

    def stat(self, name):
        actual = self._resolve(name)
        info = dict(self.metadata.get(actual))
        info["name"] = actual
        return info

    def list_files(self):
        result = []
        for name in self.metadata.names():
            info = dict(self.metadata.get(name))
            info["name"] = name
            result.append(info)
        return result

    # ======================================================== the apply step (REDO)
    def apply(self, record):
        """
        Perform the change described by a BEGIN record.

        Used by normal operations AND by recovery. Every branch is REPEATABLE
        (idempotent): running it again after it already finished changes nothing.
        The crash checkpoint sits between the data step and the metadata step,
        which is exactly where an unlucky crash leaves the two out of sync.
        """
        op, name = record["op"], record["name"]
        txid, ts = record["txid"], record.get("ts", now_string())

        if op in CONTENT_OPS:
            content = record["content"]
            self.versions.record_op(record)                        # step 0: history (old data kept)
            self.storage.write_file(name, content)                 # step 1: data
            self.crash.checkpoint("during_apply")
            self.metadata.put(name, content, txid, op, ts)         # step 2: metadata
        elif op == "snapshot":
            self.versions.ensure_objects(record["files"])          # step 1: copies of the data
            self.crash.checkpoint("during_apply")
            self.versions.record_snapshot(record)                  # step 2: the snapshot entry
        elif op == "delete":
            self.versions.record_op(record)
            self.storage.delete_file(name)
            self.crash.checkpoint("during_apply")
            self.metadata.remove(name)
        elif op == "rename":
            new_name = record["new_name"]
            self.versions.record_op(record)
            self.storage.rename_file(name, new_name)
            self.crash.checkpoint("during_apply")
            self.metadata.rename(name, new_name, txid, ts)
        else:
            raise VFSafeError("Unknown operation '%s' in journal." % op)

    # ================================================================== internals
    def _resolve(self, name):
        """Validate `name` and return the stored spelling of it (case-insensitive)."""
        name = validate_name(name)
        actual = self.metadata.find_ci(name)
        if actual is None:
            raise FileMissingError("File '%s' does not exist." % name)
        return actual

    @staticmethod
    def _decode(data, name):
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            raise StorageError("Historical data for '%s' is not valid text." % name)

    def _check_not_blocked(self):
        if self._blocked_reason:
            raise VFSafeError(self._blocked_reason)

    def _run(self, op, **fields):
        self._check_not_blocked()
        crash = self.crash
        try:
            crash.checkpoint("before_journal")
            txid = self.journal.next_txid()
            record = {"type": "BEGIN", "txid": txid, "op": op, "ts": now_string()}
            record.update(fields)
            self.journal.append(record)               # (2) write-ahead: BEGIN
            crash.checkpoint("after_journal")
            self.apply(record)                        # (3) apply (has during_apply inside)
            crash.checkpoint("after_apply")
            self.journal.append(                      # (4) COMMIT
                {"type": "COMMIT", "txid": txid, "by": "normal", "ts": now_string()}
            )
            crash.checkpoint("after_commit")
            return txid                               # (5) success
        except SimulatedCrash:
            self._blocked_reason = "This FileManager 'crashed'. Create a new one to restart."
            raise
